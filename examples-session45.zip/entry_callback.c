#include <stdio.h>
#include <string.h>

typedef struct {
    char name[16];
    void (*done)(void);
} Entry;

static void done(void)
{
    puts("Callback called.");
}

void other_done(void)
{
    puts("Other callback called.");
}

int main(int argc, char *argv[])
{
    Entry entry = { .done = done };
    Entry *e = &entry;
    const char *input = argc > 1 ? argv[1] : "Example";

    // Input with more than 15 bytes can write past the name buffer.
    strcpy(e->name, input);
    e->done();

    return 0;
}
