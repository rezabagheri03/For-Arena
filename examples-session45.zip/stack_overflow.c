#include <stdio.h>
#include <string.h>
void greet(const char * name){
char buf[16]; 
strcpy(buf, name);
}
int main(void)
{

    greet("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    return 0;
}
