#include <stdio.h>

int main(void)
{
    char input[] = "%p%p%p%p%p%p%p%p";

    printf("%s\n", input);  // Prints the literal text: %p
    printf(input);       // A pointer argument is missing. Behavior is undefined.

    return 0;
}
