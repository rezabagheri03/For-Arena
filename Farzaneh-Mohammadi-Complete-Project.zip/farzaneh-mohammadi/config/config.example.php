<?php
return [
  'app_name' => 'فرزانه محمدی',
  'base_url' => 'http://localhost/farzaneh-mohammadi/public',
  'timezone' => 'Asia/Tehran',
  'db' => ['host'=>'127.0.0.1','name'=>'farzaneh_mohammadi','user'=>'root','pass'=>'','charset'=>'utf8mb4'],
  'admin_seed_email' => 'admin@example.com',
  'admin_seed_password' => 'ChangeMe123!', // فقط برای نصب اولیه؛ بعد از ورود تغییر دهید.
];
