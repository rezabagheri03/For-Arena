<?php
// کپی config.example.php به config.php و تنظیم اطلاعات دیتابیس
return require __DIR__ . '/config.example.php';
