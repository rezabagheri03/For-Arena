<?php
declare(strict_types=1);
$config=require __DIR__.'/../config/config.php';
date_default_timezone_set($config['timezone'] ?? 'Asia/Tehran');
if (session_status() !== PHP_SESSION_ACTIVE) { session_name('farzaneh_session'); session_start(); }
function cfg(?string $key=null){global $config; return $key===null?$config:($config[$key]??null);}
function db(): PDO { static $pdo=null; if($pdo) return $pdo; $d=cfg('db'); $dsn="mysql:host={$d['host']};dbname={$d['name']};charset={$d['charset']}"; $pdo=new PDO($dsn,$d['user'],$d['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); return $pdo; }
function e($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function redirect(string $to): never { header('Location: '.$to); exit; }
function csrf(): string { if(empty($_SESSION['_csrf'])) $_SESSION['_csrf']=bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function verify_csrf(): void { if(!hash_equals(csrf(),(string)($_POST['_csrf']??''))) { http_response_code(419); exit('درخواست معتبر نیست. صفحه را تازه‌سازی کنید.'); } }
function flash(string $type,string $message): void { $_SESSION['_flash']=['type'=>$type,'message'=>$message]; }
function take_flash(): ?array { $f=$_SESSION['_flash']??null; unset($_SESSION['_flash']); return $f; }
function admin_required(): void { if(empty($_SESSION['admin_id'])) redirect('admin.php?action=login'); }
function money($n): string { return number_format((float)$n).' تومان'; }
function setting(string $key,string $default=''): string { $s=db()->prepare('SELECT setting_value FROM settings WHERE setting_key=?'); $s->execute([$key]); $v=$s->fetchColumn(); return $v===false?$default:(string)$v; }
