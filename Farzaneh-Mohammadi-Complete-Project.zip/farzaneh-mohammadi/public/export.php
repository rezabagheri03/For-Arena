<?php
require __DIR__.'/../app/bootstrap.php'; admin_required();
$type=$_GET['type']??'registrations';$queries=[
'registrations'=>['SELECT r.id AS tracking_code,a.full_name,a.phone,a.email,c.title AS course,s.title AS session,r.status,r.next_step,r.admin_note,r.created_at FROM registrations r JOIN applicants a ON a.id=r.applicant_id JOIN courses c ON c.id=r.course_id LEFT JOIN sessions s ON s.id=r.session_id ORDER BY r.id DESC','registrations'],
'payments'=>['SELECT p.id,a.full_name,a.phone,p.amount,p.method,p.reference_code,p.status,p.paid_at,p.created_at FROM payments p JOIN registrations r ON r.id=p.registration_id JOIN applicants a ON a.id=r.applicant_id ORDER BY p.id DESC','payments'],
'consultations'=>['SELECT id,full_name,phone,topic,preferred_date,preferred_time,message,status,created_at FROM consultations ORDER BY id DESC','consultations']
];if(!isset($queries[$type])){http_response_code(404);exit('Not found');}$rows=db()->query($queries[$type][0]);header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="'.$queries[$type][1].'-'.date('Ymd').'.csv"');echo "\xEF\xBB\xBF";$out=fopen('php://output','w');$first=true;while($row=$rows->fetch(PDO::FETCH_ASSOC)){if($first){fputcsv($out,array_keys($row));$first=false;}fputcsv($out,array_values($row));}fclose($out);
