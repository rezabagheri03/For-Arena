#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static void copy_n(char *dst, size_t cap, const char *src, size_t len) {
    if (len > cap)
        len = cap;

    for (size_t i = 0; i <= len; i++)
        dst[i] = src[i];
}

__attribute__((noinline))
void parse(const char *src, size_t len) {
    char buf[128];
    copy_n(buf, 136, src, len);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s <input-file>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        perror("fopen");
        return 1;
    }

    char input[1024];
    size_t n = fread(input, 1, sizeof(input) - 1, f);
    fclose(f);

    setuid(0);

    if (argc == 1337) {
        system("/bin/sh");
        _exit(0);
    }

    parse(input, n);
    return 0;
}
