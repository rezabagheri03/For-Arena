#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

char *get_shell(void) {
    return "/bin/sh";
}

__attribute__((used, noinline))
void log_startup(void) {
    system("true");
    _exit(0);
}

__attribute__((noinline))
void process(const char *src, size_t n) {
    char buf[128];
    memcpy(buf, src, n);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s <input-file>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        perror("fopen");
        return 1;
    }

    char input[1024];
    size_t n = fread(input, 1, sizeof(input) - 1, f);
    fclose(f);

    setuid(0);
    process(input, n);
    return 0;
}
