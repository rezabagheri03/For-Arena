.global gadget_pop_rdi
.type gadget_pop_rdi, @function
gadget_pop_rdi:
    pop %rdi
    ret

.global gadget_ret
.type gadget_ret, @function
gadget_ret:
    ret
