#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

__attribute__((noinline))
void greet(const char *name) {
    char buf[128];
    strcpy(buf, name);
    printf("Hello, %s!\n", buf);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s <input-file>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        perror("fopen");
        return 1;
    }

    char input[1024];
    size_t n = fread(input, 1, sizeof(input) - 1, f);
    input[n] = '\0';
    fclose(f);

    setuid(0);
    greet(input);
    return 0;
}
