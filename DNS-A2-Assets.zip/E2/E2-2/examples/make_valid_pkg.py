#!/usr/bin/env python3
"""make_valid_pkg.py — Generate a valid .pkg file for challenge1 (pkgview).

Usage:
    python3 make_valid_pkg.py [output_path]

Creates a small package with two entries that exercises the normal
(non-exploit) code path: listing and flattening.
"""

import struct
import sys

MAGIC = b"PKG1"
NAMELEN = 32

def make_entry(name: bytes, offset: int, size: int, comp_size: int) -> bytes:
    assert len(name) <= NAMELEN
    name_padded = name.ljust(NAMELEN, b"\x00")
    return name_padded + struct.pack("<III", offset, size, comp_size)

def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "input.pkg"

    entry0 = make_entry(b"hello.txt", 0, 12, 0)
    entry1 = make_entry(b"data.bin", 12, 8, 0)

    payload0 = b"Hello World!"  # 12 bytes
    payload1 = b"\xde\xad\xbe\xef\xca\xfe\xba\xbe"  # 8 bytes

    data = payload0 + payload1

    count = 2
    header_sz = 16 + count * (NAMELEN + 12)  # 16 + 2*44 = 104
    data_base = header_sz

    header = MAGIC
    header += struct.pack("<I", count)        # entry count
    header += struct.pack("<I", header_sz)    # header size
    header += struct.pack("<I", data_base)    # data base offset
    header += entry0
    header += entry1

    with open(out, "wb") as f:
        f.write(header)
        f.write(data)

    print(f"[+] wrote {len(header) + len(data)} bytes to {out}")

if __name__ == "__main__":
    main()
