#define _POSIX_C_SOURCE 200809L

/* pkgview: educational challenge; contains intentional vulnerabilities.
 * Build on Linux x86-64:
 * cc -std=c11 -O0 -g -Wall -Wextra -Wpedantic -fPIE -pie \
 *    -o challenge1 challenge1.c
 * Run with ASLR enabled: ./challenge1 valid.pkg
 * After the listing, enter another package path in the same process.
 * An empty line (or EOF) selects the original package.
 *
 * PKG1: magic[4], count:u32, header_size:u32, data_base:u32;
 * count records: name[32], offset:u32, size:u32, comp_size:u32.
 * All integers are little-endian. Offsets are relative to data_base.
 * comp_size=0 means size bytes are stored; otherwise comp_size <= size.
 * Flatten concatenates the stored bytes, without decompressing them.
 */

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if !defined(__PIE__) || __PIE__ == 0
#error "Build this challenge with -fPIE -pie (remove -fno-pie -no-pie)."
#endif

#define NAMELEN 32u
#define MAX_ENTRIES 64u
#define WORK_BUFSZ 256u
#define MAX_FILE_SIZE (1024u * 1024u)

typedef void (*output_fn)(const unsigned char *, uint32_t);

typedef struct {
    char name[NAMELEN];
    uint32_t offset;
    uint32_t size;
    uint32_t comp_size;
} entry_t;

typedef struct {
    entry_t entries[MAX_ENTRIES];
    uint32_t count;
    unsigned char *file_data;
    size_t file_len;
    size_t data_base;
} archive_t;

typedef struct {
    unsigned char work_buf[WORK_BUFSZ];
    output_fn output_cb;
} output_state_t;

_Static_assert(offsetof(output_state_t, output_cb) == WORK_BUFSZ,
               "Unsupported callback layout");

static void normal_output(const unsigned char *data, uint32_t len)
{
    uint32_t show = len < 16 ? len : 16;
    printf("OUTPUT (%u bytes):", len);
    for (uint32_t i = 0; i < show; ++i)
        printf(" %02x", data[i]);
    putchar('\n');
}

void win_output(const unsigned char *data, uint32_t len)
{
    (void)data;
    (void)len;
    const char *flag = getenv("FLAG1");
    printf("WIN %s\n", flag && *flag ? flag : "FLAG{local_pkg_cb_hijack}");
}

static uint32_t read_u32(const unsigned char *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint32_t stored_size(const entry_t *e)
{
    return e->comp_size ? e->comp_size : e->size;
}

static int parse_pkg(archive_t *arch)
{
    const unsigned char *p = arch->file_data;
    size_t len = arch->file_len;
    if (len < 16 || memcmp(p, "PKG1", 4) != 0)
        return 0;

    uint32_t count = read_u32(p + 4);
    size_t header_size = read_u32(p + 8);
    size_t data_base = read_u32(p + 12);
    if (count == 0 || count > MAX_ENTRIES ||
        header_size < 16u + (size_t)count * 44u ||
        header_size > len || data_base < header_size || data_base > len)
        return 0;

    size_t available = len - data_base;
    for (uint32_t i = 0; i < count; ++i) {
        const unsigned char *record = p + 16u + (size_t)i * 44u;
        entry_t *e = &arch->entries[i];
        memcpy(e->name, record, NAMELEN);
        e->offset = read_u32(record + 32);
        e->size = read_u32(record + 36);
        e->comp_size = read_u32(record + 40);
        uint32_t stored = stored_size(e);
        if (e->comp_size > e->size || (size_t)e->offset > available ||
            (size_t)stored > available - (size_t)e->offset)
            return 0;
    }
    arch->count = count;
    arch->data_base = data_base;
    return 1;
}

static int load_pkg(archive_t *arch, const char *path)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        perror("open package");
        return 0;
    }
    unsigned char *data = malloc(MAX_FILE_SIZE);
    if (!data) {
        perror("malloc");
        fclose(fp);
        return 0;
    }
    size_t len = fread(data, 1, MAX_FILE_SIZE, fp);
    int extra = fgetc(fp);
    int failed = ferror(fp);
    fclose(fp);
    if (failed || extra != EOF) {
        fprintf(stderr, "unreadable or oversized package (maximum %u bytes)\n",
                MAX_FILE_SIZE);
        free(data);
        return 0;
    }
    free(arch->file_data);
    memset(arch, 0, sizeof *arch);
    arch->file_data = data;
    arch->file_len = len;
    if (!parse_pkg(arch)) {
        fprintf(stderr, "invalid package\n");
        free(arch->file_data);
        memset(arch, 0, sizeof *arch);
        return 0;
    }
    return 1;
}

static void list_entries(const archive_t *arch, const output_state_t *out)
{
    printf("Archive: %u entries\n", arch->count);
    for (uint32_t i = 0; i < arch->count; ++i) {
        const entry_t *e = &arch->entries[i];
        printf("  [%u] name=", i);
        for (uint32_t j = 0; j < NAMELEN; ++j)
            printf("%02x", (unsigned char)e->name[j]);
        printf("  (size=%u comp=%u)\n", e->size, e->comp_size);
    }
    printf("workbuf preview: ");
    const unsigned char *preview = (const unsigned char *)out;
    for (size_t j = 0; j < sizeof *out; ++j)
        printf("%02x", preview[j]);
    putchar('\n');
}

static int flatten(const archive_t *arch, output_state_t *out)
{
    uint32_t total = 0;
    for (uint32_t i = 0; i < arch->count; ++i)
        total += arch->entries[i].size;
    if (total > WORK_BUFSZ) {
        printf("ERR: total %u exceeds buffer (%u)\n", total, WORK_BUFSZ);
        return 0;
    }

    size_t pos = 0;
    for (uint32_t i = 0; i < arch->count; ++i) {
        const entry_t *e = &arch->entries[i];
        size_t n = stored_size(e);
        size_t src = arch->data_base + (size_t)e->offset;
        memcpy(out->work_buf + pos, arch->file_data + src, n);
        pos += n;
    }
    out->output_cb(out->work_buf, (uint32_t)pos);
    return 1;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s PACKAGE\n", argv[0]);
        return 2;
    }
    setvbuf(stdout, NULL, _IONBF, 0);
    archive_t arch = {0};
    output_state_t out;
    memset(&out, 0, sizeof out);
    out.output_cb = normal_output;
    if (!load_pkg(&arch, argv[1]))
        return 1;

    list_entries(&arch, &out);
    printf("Package to flatten (empty: current): ");
    char path[4096];
    if (fgets(path, sizeof path, stdin)) {
        char *end = strchr(path, '\n');
        if (!end && !feof(stdin)) {
            fprintf(stderr, "package path too long\n");
            free(arch.file_data);
            return 1;
        }
        path[strcspn(path, "\r\n")] = '\0';
        if (*path && !load_pkg(&arch, path)) {
            free(arch.file_data);
            return 1;
        }
    } else if (ferror(stdin)) {
        perror("read package path");
        free(arch.file_data);
        return 1;
    }

    int ok = flatten(&arch, &out);
    free(arch.file_data);
    return ok ? 0 : 1;
}
