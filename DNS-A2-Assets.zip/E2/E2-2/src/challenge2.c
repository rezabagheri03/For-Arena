#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---------------------------------------------------------------------------
 * minish — Mini Interactive Shell
 *
 * A toy shell that accepts commands from stdin.  The command syntax and
 * dispatch path are intentionally small for the exercise.
 * --------------------------------------------------------------------------- */

/* ---------- constants ---------- */

#define MAX_ALIASES   8u
#define ALIAS_NAMELEN 16u
#define LINE_SZ       256u

/* ---------- flag ---------- */

static const char *flag_value(void)
{
    const char *v = getenv("FLAG2");
    return v && *v ? v : "FLAG{local_fmt_oob_chain}";
}

/* ---------- command handler type ---------- */

typedef void (*cmd_fn)(const char *args);

/* ---------- alias table + default handler ---------- */

typedef struct {
    char   name[ALIAS_NAMELEN];
    cmd_fn handler;
} alias_t;

/*
 * All globals are inside a struct so the memory layout is deterministic:
 *   aliases[0..7]    offset   0  (8 × 24 = 192 bytes)
 *   default_handler   offset 192  (8 bytes)  ← aliases[8].name starts here
 *   alias_count       offset 200  (4 bytes)
 *   _pad              offset 204  (12 bytes)  ← absorbs aliases[8].handler write
 */
static struct {
    alias_t  aliases[MAX_ALIASES];
    cmd_fn   default_handler;
    int      alias_count;
    char     _pad[12];
} g;

/* ---------- forward declarations ---------- */

static void cmd_echo(const char *args);
static void cmd_alias(const char *args);
static void cmd_help(const char *args);
static void cmd_quit(const char *args);

/* ---------- built-in commands ---------- */

static void cmd_echo(const char *args)
{
    /* Deliberately unsafe for the exercise. */
    printf(args);
    printf("\n");
}

static void cmd_alias(const char *args)
{
    /* syntax:  alias  HEX_NAME  INDEX  HANDLER_NAME
     *   HEX_NAME = hex-encoded bytes for the alias name (up to 32 hex chars → 16 bytes)
     *   INDEX    = signed integer index into aliases[]
     *   HANDLER_NAME = "echo" | "alias" | "help" | "quit"
     *
     * The upper-bound check is intentionally part of the exercise. */
    char hex_name[ALIAS_NAMELEN * 2 + 2] = {0};
    char hname[ALIAS_NAMELEN] = {0};
    int  index = 0;

    if (sscanf(args, "%32s %d %15s", hex_name, &index, hname) < 3) {
        printf("ERR: usage: alias HEXNAME INDEX HANDLER\n");
        return;
    }

    /* decode hex → raw bytes */
    unsigned char raw[ALIAS_NAMELEN] = {0};
    size_t hex_len = strlen(hex_name);
    if ((hex_len & 1) != 0 || hex_len / 2 > ALIAS_NAMELEN) {
        printf("ERR: hex name must have even length, max %u chars\n", ALIAS_NAMELEN * 2);
        return;
    }
    for (size_t i = 0; i < hex_len; i += 2) {
        if (!isxdigit((unsigned char)hex_name[i]) ||
            !isxdigit((unsigned char)hex_name[i + 1])) {
            printf("ERR: invalid hex\n");
            return;
        }
        unsigned int hi = (unsigned int)(isdigit((unsigned char)hex_name[i])
                            ? hex_name[i] - '0'
                            : tolower((unsigned char)hex_name[i]) - 'a' + 10);
        unsigned int lo = (unsigned int)(isdigit((unsigned char)hex_name[i + 1])
                            ? hex_name[i + 1] - '0'
                            : tolower((unsigned char)hex_name[i + 1]) - 'a' + 10);
        raw[i / 2] = (unsigned char)((hi << 4) | lo);
    }

    /* ----- resolve handler ----- */
    cmd_fn fn = NULL;
    if      (strcmp(hname, "echo")  == 0) fn = cmd_echo;
    else if (strcmp(hname, "alias") == 0) fn = cmd_alias;
    else if (strcmp(hname, "help")  == 0) fn = cmd_help;
    else if (strcmp(hname, "quit")  == 0) fn = cmd_quit;
    else {
        printf("ERR: unknown handler '%s'\n", hname);
        return;
    }

    /* The inclusive upper bound is intentional for the exercise. */
    if (index >= 0 && index <= (int)MAX_ALIASES) {
        memcpy(g.aliases[index].name, raw, ALIAS_NAMELEN);
        g.aliases[index].handler = fn;
        if (index < (int)MAX_ALIASES && index >= g.alias_count)
            g.alias_count = index + 1;
        printf("OK alias %d -> %s\n", index, hname);
    } else {
        printf("ERR: index %d out of range\n", index);
    }
}

static void cmd_help(const char *args)
{
    (void)args;
    printf("commands: echo <text> | alias <name> <idx> <h> | help | quit\n");
}

static void cmd_quit(const char *args)
{
    (void)args;
    exit(0);
}

/* win handler — called when default_handler is hijacked */
void win_handler(const char *args)
{
    (void)args;
    printf("WIN %s\n", flag_value());
}

/* ---------- command dispatch ---------- */

typedef struct {
    const char *name;
    cmd_fn      fn;
} builtin_t;

static const builtin_t builtins[] = {
    {"echo",  cmd_echo},
    {"alias", cmd_alias},
    {"help",  cmd_help},
    {"quit",  cmd_quit},
};
enum { BUILTIN_COUNT = sizeof builtins / sizeof builtins[0] };

static cmd_fn lookup_builtin(const char *name)
{
    for (size_t i = 0; i < BUILTIN_COUNT; i++)
        if (strcmp(builtins[i].name, name) == 0)
            return builtins[i].fn;
    return NULL;
}

static cmd_fn lookup_alias(const char *name)
{
    size_t name_len = strlen(name);
    if (name_len > ALIAS_NAMELEN)
        return NULL;

    for (int i = 0; i < g.alias_count; i++)
        if (memcmp(g.aliases[i].name, name, name_len) == 0 &&
            (name_len == ALIAS_NAMELEN || g.aliases[i].name[name_len] == '\0'))
            return g.aliases[i].handler;
    return NULL;
}

/* ---------- main loop ---------- */

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    g.default_handler = NULL;   /* unset — triggers "unknown command" */

    char line[LINE_SZ];
    printf("minish>\n"); fflush(stdout);

    while (fgets(line, sizeof line, stdin)) {
        /* strip trailing whitespace */
        char *end = line + strlen(line);
        while (end > line && isspace((unsigned char)end[-1])) *--end = '\0';

        /* split into command + args */
        char *save = NULL;
        char *cmd  = strtok_r(line, " \t", &save);
        if (!cmd) goto next;

        char *args = strtok_r(NULL, "", &save);  /* rest of line */
        if (!args) args = "";

        /* ----- resolve handler ----- */
        cmd_fn handler = lookup_builtin(cmd);
        if (!handler) handler = lookup_alias(cmd);
        if (!handler) handler = g.default_handler;   /* <-- hijacked target */

        if (handler)
            handler(args);
        else
            printf("ERR: unknown command '%s'\n", cmd);

    next:
        printf("minish>\n"); fflush(stdout);
    }
    return 0;
}
