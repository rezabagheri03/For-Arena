# Homework 2 package

## Reference environment

The supplied reference binaries and the expected stack layout were checked on:

- Linux x86-64
- Debian 13
- GCC 14.2.0
- glibc 2.41
- ASLR enabled: `/proc/sys/kernel/randomize_va_space` is `2`

Use a Linux virtual machine. The first section is designed for this reference
environment; compiler or optimization changes can alter stack addresses.

## Section 1: target programs

```sh
cd E2-1
make clean all
```

The binaries are written to `E2-1/build/`. To install the setuid targets in a
test VM:

```sh
sudo make install
```

This installs `/tmp/target1`, `/tmp/target2`, and `/tmp/target3` with mode
`4755`. Do not run these programs on a production system.

`target2` uses the reference build's stack layout. Its source writes up to
137 bytes from a 128-byte buffer; in the reference binary, the final byte
reaches the least-significant byte of the saved return address.

## Section 2: challenge programs

```sh
cd E2-2
make clean all
```

The binaries are written to `E2-2/build/`. PIE is enabled and ASLR should
remain enabled.

Run `pkgview` with the supplied package as follows:

```sh
FLAG1='FLAG{local_challenge_1}' ./build/challenge1 examples/input.pkg
```

After `pkgview` prints its preview, it asks for a second package path in the
same process. Enter the path to the package to be flattened; an empty line or
EOF keeps the original package.

Run the shell challenge with:

```sh
FLAG2='FLAG{local_challenge_2}' ./build/challenge2
```

The local flag values are only examples. The grading environment supplies its
own values through `FLAG1` and `FLAG2`.

## Examples

`examples/input.pkg` is the package used by the `challenge1` command above.
`examples/challenge2-normal.txt` contains a normal interaction for
`challenge2`.
