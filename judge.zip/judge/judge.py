#!/usr/bin/env python3
"""Run a phase-3 compiler against the local test suite.

Usage:
    python3 judge.py [path/to/compiler.py]
    python3 judge.py path/to/compiler_directory --tests path/to/testcases

For each test, the judge compiles input.txt in an isolated temporary directory,
executes the generated three-address code, writes actual.txt next to the test,
and compares actual.txt with expected.txt.  Generated TAC is deliberately not
compared with the reference output.txt because many different TAC programs can
produce the same correct result.
"""

import argparse
import difflib
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


INSTRUCTION_PATTERN = re.compile(
    r"^\s*(\d+)\s+\(\s*([A-Z]+)\s*,\s*([^,]*)\s*,\s*([^,]*)\s*,\s*([^)]*)\s*\)\s*$"
)

ALLOWED_OPERATIONS = {
    "ADD",
    "MULT",
    "SUB",
    "DIV",
    "EQ",
    "LT",
    "ASSIGN",
    "JPF",
    "JP",
    "PRINT",
}

GENERATED_FILE_NAMES = {
    "input.txt",
    "output.txt",
    "actual.txt",
    "expected.txt",
    "tokens.txt",
    "lexical_errors.txt",
    "syntax_errors.txt",
    "semantic_errors.txt",
    "symbol_table.txt",
    "parse_tree.txt",
}


class JudgeError(Exception):
    pass


def parse_instructions(output_path):
    instructions = []
    for raw_line in output_path.read_text(encoding="utf-8").splitlines():
        if not raw_line.strip():
            continue
        match = INSTRUCTION_PATTERN.fullmatch(raw_line)
        if match is None:
            raise JudgeError("Invalid TAC line: {}".format(raw_line))

        written_index = int(match.group(1))
        if written_index != len(instructions):
            raise JudgeError(
                "Expected instruction number {}, got {}".format(
                    len(instructions), written_index
                )
            )

        operation = match.group(2)
        if operation not in ALLOWED_OPERATIONS:
            raise JudgeError("Unsupported operation: {}".format(operation))

        operands = tuple(match.group(index).strip() for index in (3, 4, 5))
        instructions.append((operation,) + operands)

    if not instructions:
        raise JudgeError("output.txt is empty")
    return instructions


def execute_instructions(instructions, max_steps):
    memory = {}
    program_counter = 0
    steps = 0
    printed_values = []

    def read_memory(address):
        if address not in memory:
            raise JudgeError("Invalid access to memory address {}".format(address))
        return memory[address]

    def numeric_part(operand):
        if not operand:
            raise JudgeError("Missing instruction operand")
        text = operand[1:] if operand[0] in "#@" else operand
        try:
            return int(text)
        except ValueError:
            raise JudgeError("Invalid operand: {}".format(operand))

    def resolve(operand):
        lowered = operand.lower()
        if lowered == "true":
            return 1
        if lowered == "false":
            return 0

        number = numeric_part(operand)
        if operand.startswith("#"):
            return number
        if operand.startswith("@"):
            return read_memory(read_memory(number))
        return read_memory(number)

    def resolve_destination(operand):
        number = numeric_part(operand)
        if operand.startswith("@"):
            return read_memory(number)
        return number

    def store(destination, value):
        memory[resolve_destination(destination)] = value

    while program_counter < len(instructions):
        if program_counter < 0:
            raise JudgeError("Negative program counter")
        steps += 1
        if steps > max_steps:
            raise JudgeError(
                "Execution exceeded {} instructions (possible infinite loop)".format(
                    max_steps
                )
            )

        operation, first, second, result = instructions[program_counter]
        program_counter += 1

        if operation == "ASSIGN":
            destination = resolve_destination(second)
            # Match the course tester: ASSIGN creates a direct destination
            # before resolving the source operand.
            if destination not in memory:
                memory[destination] = 0
            store(second, resolve(first))
        elif operation == "ADD":
            store(result, resolve(first) + resolve(second))
        elif operation == "MULT":
            store(result, resolve(first) * resolve(second))
        elif operation == "SUB":
            store(result, resolve(first) - resolve(second))
        elif operation == "DIV":
            store(result, resolve(first) // resolve(second))
        elif operation == "EQ":
            store(result, int(resolve(first) == resolve(second)))
        elif operation == "LT":
            store(result, int(resolve(first) < resolve(second)))
        elif operation == "JPF":
            if not resolve(first):
                program_counter = resolve_destination(second)
        elif operation == "JP":
            program_counter = resolve_destination(first)
        elif operation == "PRINT":
            printed_values.append(resolve(first))

    return "".join("PRINT    {}\n".format(value) for value in printed_values)


def copy_compiler_bundle(source_directory, destination_directory):
    copied_files = 0
    for source in source_directory.iterdir():
        if not source.is_file() or source.name in GENERATED_FILE_NAMES:
            continue
        shutil.copy2(str(source), str(destination_directory / source.name))
        copied_files += 1
    if copied_files == 0:
        raise JudgeError("No compiler files found in {}".format(source_directory))


def resolve_compiler(compiler_argument):
    compiler_path = Path(compiler_argument).resolve()
    if compiler_path.is_dir():
        compiler_path = compiler_path / "compiler.py"
    if not compiler_path.is_file():
        raise JudgeError("Compiler entry file not found: {}".format(compiler_path))
    return compiler_path


def test_sort_key(test_directory):
    match = re.fullmatch(r"T(\d+)", test_directory.name)
    if match:
        return (0, int(match.group(1)))
    return (1, test_directory.name)


def run_test(test_directory, compiler_path, timeout, max_steps):
    input_path = test_directory / "input.txt"
    expected_path = test_directory / "expected.txt"
    actual_path = test_directory / "actual.txt"

    if not input_path.is_file():
        raise JudgeError("{} has no input.txt".format(test_directory.name))
    if not expected_path.is_file():
        raise JudgeError("{} has no expected.txt".format(test_directory.name))
    with tempfile.TemporaryDirectory(prefix="phase3_judge_") as temporary_name:
        temporary_directory = Path(temporary_name)
        copy_compiler_bundle(compiler_path.parent, temporary_directory)
        shutil.copy2(str(input_path), str(temporary_directory / "input.txt"))

        temporary_compiler = temporary_directory / compiler_path.name
        try:
            completed = subprocess.run(
                [sys.executable, str(temporary_compiler)],
                cwd=str(temporary_directory),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            raise JudgeError("compiler timed out after {} seconds".format(timeout))

        if completed.returncode != 0:
            details = completed.stderr.strip() or completed.stdout.strip()
            raise JudgeError(
                "compiler exited with code {}{}".format(
                    completed.returncode,
                    ": " + details if details else "",
                )
            )

        generated_output = temporary_directory / "output.txt"
        if not generated_output.is_file():
            raise JudgeError("compiler did not create output.txt")

        instructions = parse_instructions(generated_output)
        actual_text = execute_instructions(instructions, max_steps)
        actual_path.write_text(actual_text, encoding="utf-8")

    expected_text = expected_path.read_text(encoding="utf-8")
    return actual_text == expected_text, expected_text, actual_text


def make_diff(expected_text, actual_text):
    return "".join(
        difflib.unified_diff(
            expected_text.splitlines(True),
            actual_text.splitlines(True),
            fromfile="expected.txt",
            tofile="actual.txt",
        )
    )


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Compile and execute phase-3 test cases."
    )
    parser.add_argument(
        "compiler",
        nargs="?",
        default="compiler.py",
        help="path to compiler.py or its containing directory (default: compiler.py)",
    )
    parser.add_argument(
        "--tests",
        default="testcases",
        help="testcases directory (default: testcases)",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=5.0,
        help="compiler timeout per test in seconds (default: 5)",
    )
    parser.add_argument(
        "--max-steps",
        type=int,
        default=1_000_000,
        help="maximum VM instructions per test (default: 1000000)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="only print failures and the final summary",
    )
    return parser.parse_args()


def main():
    arguments = parse_arguments()
    try:
        compiler_path = resolve_compiler(arguments.compiler)
        tests_path = Path(arguments.tests).resolve()
        if not tests_path.is_dir():
            raise JudgeError("Testcases directory not found: {}".format(tests_path))

        test_directories = sorted(
            (
                path
                for path in tests_path.iterdir()
                if path.is_dir() and re.fullmatch(r"T\d+", path.name)
            ),
            key=test_sort_key,
        )
        if not test_directories:
            raise JudgeError("No T<number> test directories found")

        passed = 0
        for test_directory in test_directories:
            actual_path = test_directory / "actual.txt"
            try:
                if actual_path.exists():
                    actual_path.unlink()
                try:
                    is_correct, expected_text, actual_text = run_test(
                        test_directory,
                        compiler_path,
                        arguments.timeout,
                        arguments.max_steps,
                    )
                    if is_correct:
                        passed += 1
                        if not arguments.quiet:
                            values = ", ".join(actual_text.splitlines()) or "<no output>"
                            print("PASS {}: {}".format(test_directory.name, values))
                    else:
                        print("FAIL {}: wrong program output".format(test_directory.name))
                        print(make_diff(expected_text, actual_text), end="")
                except (JudgeError, OSError, ZeroDivisionError) as error:
                    print("FAIL {}: {}".format(test_directory.name, error))
            finally:
                if actual_path.exists():
                    actual_path.unlink()

        total = len(test_directories)
        print("\nResult: {}/{} tests passed.".format(passed, total))
        return 0 if passed == total else 1
    except JudgeError as error:
        print("Judge error: {}".format(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
