#!/usr/bin/env python3
"""Judge phase-3 mandatory, semantic-bonus, or recursive-bonus tests.

Examples:
    python3 judge.py --mode mandatory
    python3 judge.py --mode semantic path/to/student/compiler.py
    python3 judge.py --mode recursive path/to/student_directory

Short aliases T, S, and R are accepted for the three modes.
Mandatory/recursive modes execute generated TAC and compare the PRINT stream
with expected.txt. Semantic mode compares semantic_errors.txt exactly.
"""

import argparse
import difflib
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

INSTRUCTION_PATTERN = re.compile(
    r"^\s*(\d+)\s+\(\s*([A-Z]+)\s*,\s*([^,]*)\s*,\s*([^,]*)\s*,\s*([^)]*)\s*\)\s*$"
)
ALLOWED_OPERATIONS = {"ADD", "MULT", "SUB", "DIV", "EQ", "LT", "ASSIGN", "JPF", "JP", "PRINT"}
GENERATED_FILE_NAMES = {
    "input.txt", "output.txt", "actual.txt", "actual_semantic_errors.txt",
    "expected.txt", "tokens.txt", "lexical_errors.txt", "syntax_errors.txt",
    "semantic_errors.txt", "symbol_table.txt", "parse_tree.txt",
}
MODE_ALIASES = {
    "mandatory": ("mandatory", "T"), "t": ("mandatory", "T"),
    "semantic": ("semantic", "S"), "s": ("semantic", "S"),
    "recursive": ("recursive", "R"), "r": ("recursive", "R"),
}

class JudgeError(Exception):
    pass


def parse_instructions(output_path):
    instructions = []
    for raw_line in output_path.read_text(encoding="utf-8").splitlines():
        if not raw_line.strip():
            continue
        match = INSTRUCTION_PATTERN.fullmatch(raw_line)
        if match is None:
            raise JudgeError("Invalid TAC line: {}".format(raw_line))
        written_index = int(match.group(1))
        if written_index != len(instructions):
            raise JudgeError("Expected instruction number {}, got {}".format(len(instructions), written_index))
        operation = match.group(2)
        if operation not in ALLOWED_OPERATIONS:
            raise JudgeError("Unsupported operation: {}".format(operation))
        operands = tuple(match.group(index).strip() for index in (3, 4, 5))
        instructions.append((operation,) + operands)
    if not instructions:
        raise JudgeError("output.txt is empty")
    return instructions


def execute_instructions(instructions, max_steps):
    memory = {}
    program_counter = 0
    steps = 0
    printed_values = []

    def read_memory(address):
        if address not in memory:
            raise JudgeError("Invalid access to memory address {}".format(address))
        return memory[address]

    def numeric_part(operand):
        if not operand:
            raise JudgeError("Missing instruction operand")
        text = operand[1:] if operand[0] in "#@" else operand
        try:
            return int(text)
        except ValueError:
            raise JudgeError("Invalid operand: {}".format(operand))

    def resolve(operand):
        lowered = operand.lower()
        if lowered == "true":
            return 1
        if lowered == "false":
            return 0
        number = numeric_part(operand)
        if operand.startswith("#"):
            return number
        if operand.startswith("@"):
            return read_memory(read_memory(number))
        return read_memory(number)

    def resolve_destination(operand):
        number = numeric_part(operand)
        if operand.startswith("@"):
            return read_memory(number)
        return number

    def store(destination, value):
        memory[resolve_destination(destination)] = value

    while program_counter < len(instructions):
        if program_counter < 0:
            raise JudgeError("Negative program counter")
        steps += 1
        if steps > max_steps:
            raise JudgeError("Execution exceeded {} instructions (possible infinite loop)".format(max_steps))
        operation, first, second, result = instructions[program_counter]
        program_counter += 1
        if operation == "ASSIGN":
            destination = resolve_destination(second)
            if destination not in memory:
                memory[destination] = 0
            store(second, resolve(first))
        elif operation == "ADD":
            store(result, resolve(first) + resolve(second))
        elif operation == "MULT":
            store(result, resolve(first) * resolve(second))
        elif operation == "SUB":
            store(result, resolve(first) - resolve(second))
        elif operation == "DIV":
            store(result, resolve(first) // resolve(second))
        elif operation == "EQ":
            store(result, int(resolve(first) == resolve(second)))
        elif operation == "LT":
            store(result, int(resolve(first) < resolve(second)))
        elif operation == "JPF":
            if not resolve(first):
                program_counter = resolve_destination(second)
        elif operation == "JP":
            program_counter = resolve_destination(first)
        elif operation == "PRINT":
            printed_values.append(resolve(first))
    return "".join("PRINT    {}\n".format(value) for value in printed_values)


def copy_compiler_bundle(source_directory, destination_directory):
    copied_files = 0
    for source in source_directory.iterdir():
        if not source.is_file() or source.name in GENERATED_FILE_NAMES:
            continue
        shutil.copy2(str(source), str(destination_directory / source.name))
        copied_files += 1
    if copied_files == 0:
        raise JudgeError("No compiler files found in {}".format(source_directory))


def resolve_compiler(compiler_argument):
    compiler_path = Path(compiler_argument).resolve()
    if compiler_path.is_dir():
        compiler_path = compiler_path / "compiler.py"
    if not compiler_path.is_file():
        raise JudgeError("Compiler entry file not found: {}".format(compiler_path))
    return compiler_path


def resolve_mode(mode_argument):
    key = mode_argument.lower()
    if key not in MODE_ALIASES:
        raise JudgeError("Unknown mode {!r}; use mandatory/T, semantic/S, or recursive/R".format(mode_argument))
    return MODE_ALIASES[key]


def test_sort_key(prefix, test_directory):
    match = re.fullmatch(re.escape(prefix) + r"(\d+)", test_directory.name)
    return int(match.group(1)) if match else 10 ** 9


def compile_in_temp(test_directory, compiler_path, timeout):
    input_path = test_directory / "input.txt"
    if not input_path.is_file():
        raise JudgeError("{} has no input.txt".format(test_directory.name))
    temporary = tempfile.TemporaryDirectory(prefix="phase3_judge_")
    temporary_directory = Path(temporary.name)
    copy_compiler_bundle(compiler_path.parent, temporary_directory)
    shutil.copy2(str(input_path), str(temporary_directory / "input.txt"))
    temporary_compiler = temporary_directory / compiler_path.name
    try:
        completed = subprocess.run(
            [sys.executable, str(temporary_compiler)], cwd=str(temporary_directory),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        temporary.cleanup()
        raise JudgeError("compiler timed out after {} seconds".format(timeout))
    if completed.returncode != 0:
        details = completed.stderr.strip() or completed.stdout.strip()
        temporary.cleanup()
        raise JudgeError("compiler exited with code {}{}".format(completed.returncode, ": " + details if details else ""))
    return temporary, temporary_directory


def run_tac_test(test_directory, compiler_path, timeout, max_steps):
    expected_path = test_directory / "expected.txt"
    if not expected_path.is_file():
        raise JudgeError("{} has no expected.txt".format(test_directory.name))
    temporary, td = compile_in_temp(test_directory, compiler_path, timeout)
    try:
        generated_output = td / "output.txt"
        if not generated_output.is_file():
            raise JudgeError("compiler did not create output.txt")
        instructions = parse_instructions(generated_output)
        actual_text = execute_instructions(instructions, max_steps)
    finally:
        temporary.cleanup()
    expected_text = expected_path.read_text(encoding="utf-8")
    return actual_text == expected_text, expected_text, actual_text


def run_semantic_test(test_directory, compiler_path, timeout, max_steps):
    del max_steps
    expected_path = test_directory / "semantic_errors.txt"
    if not expected_path.is_file():
        raise JudgeError("{} has no semantic_errors.txt reference".format(test_directory.name))
    temporary, td = compile_in_temp(test_directory, compiler_path, timeout)
    try:
        generated = td / "semantic_errors.txt"
        if not generated.is_file():
            raise JudgeError("compiler did not create semantic_errors.txt")
        actual_text = generated.read_text(encoding="utf-8")
    finally:
        temporary.cleanup()
    expected_text = expected_path.read_text(encoding="utf-8")
    return actual_text == expected_text, expected_text, actual_text


def make_diff(expected_text, actual_text, semantic=False):
    return "".join(difflib.unified_diff(
        expected_text.splitlines(True), actual_text.splitlines(True),
        fromfile="semantic_errors.txt (expected)" if semantic else "expected.txt",
        tofile="semantic_errors.txt (actual)" if semantic else "actual.txt",
    ))


def parse_arguments():
    parser = argparse.ArgumentParser(description="Test phase-3 mandatory or optional compiler tasks.")
    parser.add_argument("compiler", nargs="?", default="compiler.py", help="compiler.py or its directory")
    parser.add_argument("--mode", "-m", default="mandatory", help="mandatory/T, semantic/S, or recursive/R")
    parser.add_argument("--tests", default="testcases", help="testcases directory (default: testcases)")
    parser.add_argument("--timeout", type=float, default=5.0, help="compiler timeout per test")
    parser.add_argument("--max-steps", type=int, default=1000000, help="maximum VM instructions per TAC test")
    parser.add_argument("--quiet", action="store_true", help="only print failures and summary")
    parser.add_argument("--from", dest="from_number", type=int, default=None, help="first test number to run")
    parser.add_argument("--to", dest="to_number", type=int, default=None, help="last test number to run")
    return parser.parse_args()


def main():
    args = parse_arguments()
    try:
        mode, prefix = resolve_mode(args.mode)
        compiler_path = resolve_compiler(args.compiler)
        tests_path = Path(args.tests).resolve()
        if not tests_path.is_dir():
            raise JudgeError("Testcases directory not found: {}".format(tests_path))
        test_directories = []
        pattern = re.compile(re.escape(prefix) + r"(\d+)")
        for path in tests_path.iterdir():
            if not path.is_dir():
                continue
            match = pattern.fullmatch(path.name)
            if match is None:
                continue
            number = int(match.group(1))
            if args.from_number is not None and number < args.from_number:
                continue
            if args.to_number is not None and number > args.to_number:
                continue
            test_directories.append(path)
        test_directories.sort(key=lambda p: test_sort_key(prefix, p))
        if not test_directories:
            raise JudgeError("No {}<number> test directories found for {} mode".format(prefix, mode))

        runner = run_semantic_test if mode == "semantic" else run_tac_test
        passed = 0
        for test_directory in test_directories:
            try:
                correct, expected_text, actual_text = runner(
                    test_directory, compiler_path, args.timeout, args.max_steps
                )
                if correct:
                    passed += 1
                    if not args.quiet:
                        detail = actual_text.strip().replace("\n", " | ") or "<empty>"
                        print("PASS {}: {}".format(test_directory.name, detail))
                else:
                    print("FAIL {}: wrong {}".format(
                        test_directory.name,
                        "semantic_errors.txt" if mode == "semantic" else "program output",
                    ))
                    print(make_diff(expected_text, actual_text, mode == "semantic"), end="")
            except (JudgeError, OSError, ZeroDivisionError) as error:
                print("FAIL {}: {}".format(test_directory.name, error))

        total = len(test_directories)
        print("\nMode: {} | Result: {}/{} tests passed.".format(mode, passed, total))
        return 0 if passed == total else 1
    except JudgeError as error:
        print("Judge error: {}".format(error), file=sys.stderr)
        return 2

if __name__ == "__main__":
    sys.exit(main())
